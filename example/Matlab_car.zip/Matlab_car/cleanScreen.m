function cleanScreen();

display_picture('internal_images/black.jpg', 1, '', 1, 0);
display_picture('internal_images/black.jpg', 1, '', 2, 0);
display_picture('internal_images/black.jpg', 1, '', 3, 0);
display_picture('internal_images/black.jpg', 1, '', 4, 0);

return;
